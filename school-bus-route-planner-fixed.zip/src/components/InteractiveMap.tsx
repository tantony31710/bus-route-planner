import React, { useMemo, useState, useEffect, useRef, useCallback } from 'react';
import { Student, RouteStop, TrafficSegment } from '../types';
import { Bus, Layers, LocateFixed, LocateOff, Navigation, ExternalLink, RefreshCw, ArrowRight } from 'lucide-react';

// ── API Key ───────────────────────────────────────────────────────────────────
const API_KEY: string =
  (import.meta as any).env?.VITE_GOOGLE_MAPS_PLATFORM_KEY ||
  (globalThis as any).GOOGLE_MAPS_PLATFORM_KEY ||
  '';


type MapView = '2d' | '3d' | 'directions';

interface InteractiveMapProps {
  students: Student[];
  routeStops: RouteStop[];
  currentStopIndex: number;
  simulatedBusPos: { lat: number; lng: number } | null;
  trafficSegments: TrafficSegment[];
  liveDriverPos?: { lat: number; lng: number } | null;
  gpsStatus?: 'idle' | 'requesting' | 'active' | 'denied' | 'unavailable';
  onRequestGps?: () => void;
  onStopGps?: () => void;
  onSelectStudent?: (studentId: string) => void;
}

// ── Leaflet + OSRM Directions Panel — Step-by-step navigation ───────────────
function DirectionsPanel({
  stops,
  liveDriverPos,
}: {
  stops: RouteStop[];
  liveDriverPos?: { lat: number; lng: number } | null;
}) {
  const hubStops = stops.filter(s => s.type === 'hub');
  const studentStops = stops.filter(s => s.type !== 'hub');

  // Build ordered stop list: origin → students → destination
  const origin = liveDriverPos
    ? { lat: liveDriverPos.lat, lng: liveDriverPos.lng, name: '📍 Your Location', isHub: true }
    : hubStops[0]
      ? { lat: hubStops[0].lat, lng: hubStops[0].lng, name: hubStops[0].name, isHub: true }
      : null;

  const dest = hubStops.length > 1
    ? { lat: hubStops[hubStops.length - 1].lat, lng: hubStops[hubStops.length - 1].lng, name: hubStops[hubStops.length - 1].name, isHub: true }
    : { lat: 30.0965, lng: 31.3160, name: 'St. Mary Church Complex', isHub: true };

  const allStops = useMemo(() => {
    if (!origin) return [];
    return [
      origin,
      ...studentStops.map(s => ({ lat: s.lat, lng: s.lng, name: s.name, eta: s.eta, isHub: false })),
      dest,
    ];
  }, [stops, liveDriverPos]);

  const [started, setStarted] = useState(false);
  const [currentIdx, setCurrentIdx] = useState(0); // index into allStops
  const [refreshKey, setRefreshKey] = useState(0);

  // Reset when stops change
  useEffect(() => {
    setStarted(false);
    setCurrentIdx(0);
  }, [stops.length]);

  const totalLegs = allStops.length - 1; // number of segments
  const isLast = currentIdx >= totalLegs;
  const isFirst = currentIdx === 0;

  const from = allStops[currentIdx];
  const to = allStops[currentIdx + 1];

  // Google Maps URL for JUST the current leg (opens in phone for navigation)
  const legNavUrl = useMemo(() => {
    if (!from || !to) return '#';
    return `https://www.google.com/maps/dir/${from.lat},${from.lng}/${to.lat},${to.lng}`;
  }, [from, to]);

  // Full route Google Maps URL
  const fullNavUrl = useMemo(() => {
    if (!origin) return '#';
    const o = `${origin.lat},${origin.lng}`;
    const d = `${dest.lat},${dest.lng}`;
    const wps = studentStops.slice(0, 9).map(s => `${s.lat},${s.lng}`).join('/');
    return `https://www.google.com/maps/dir/${o}/${wps ? wps + '/' : ''}${d}`;
  }, [stops, liveDriverPos]);

  // Leaflet HTML — shows ONLY current leg (from → to) via OSRM
  // This eliminates road-crossing: OSRM routes one clean segment at a time
  const leafletHtml = useMemo(() => {
    if (!from || !to) return '';

    const coordsForOsrm = `[${from.lng},${from.lat}],[${to.lng},${to.lat}]`;
    const centerLat = (from.lat + to.lat) / 2;
    const centerLng = (from.lng + to.lng) / 2;

    // All stop markers (dimmed) + highlight current and next
    const allMarkers = allStops.map((s, i) => {
      const isCurrent = i === currentIdx;
      const isNext = i === currentIdx + 1;
      const isPast = i < currentIdx;
      const color = isCurrent ? '#10B981' : isNext ? '#3B82F6' : isPast ? '#374151' : '#F59E0B';
      const radius = isCurrent || isNext ? 10 : 6;
      const opacity = isPast ? 0.3 : 1;
      const label = i === 0 ? 'START' : i === allStops.length - 1 ? 'END' : `${i}`;
      const safePopup = (s.name || label).replace(/'/g, "\'").replace(/"/g, '\"');
      return `
        L.circleMarker([${s.lat}, ${s.lng}], {
          radius: ${radius}, fillColor: '${color}', color: '#fff',
          weight: ${isCurrent || isNext ? 2.5 : 1.5}, opacity: ${opacity}, fillOpacity: ${opacity * 0.95}
        }).addTo(map).bindPopup('<b>${safePopup}</b>');
      `;
    }).join('');

    return `<!DOCTYPE html>
<html><head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>* {margin:0;padding:0;box-sizing:border-box;} html,body,#map{height:100%;width:100%;}</style>
</head><body>
<div id="map"></div>
<script>
var map = L.map('map',{zoomControl:true}).setView([${centerLat},${centerLng}],16);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
  attribution:'© OpenStreetMap',maxZoom:19
}).addTo(map);

${allMarkers}

// Route ONLY the current leg: ${from.name} → ${to?.name ?? 'next'}
var osrmUrl = 'https://router.project-osrm.org/route/v1/driving/${from.lng},${from.lat};${to.lng},${to.lat}?overview=full&geometries=geojson';

fetch(osrmUrl)
  .then(function(r){return r.json();})
  .then(function(data){
    if(data.routes && data.routes[0]){
      var latlngs = data.routes[0].geometry.coordinates.map(function(c){return [c[1],c[0]];});
      L.polyline(latlngs,{color:'#0F172A',weight:9,opacity:0.8}).addTo(map);
      L.polyline(latlngs,{color:'#3B82F6',weight:5,opacity:1}).addTo(map);
      map.fitBounds(L.polyline(latlngs).getBounds(),{padding:[40,40]});
    }
  })
  .catch(function(){
    L.polyline([[${from.lat},${from.lng}],[${to.lat},${to.lng}]],
      {color:'#3B82F6',weight:4,dashArray:'10,8'}).addTo(map);
  });
</script></body></html>`;
  }, [currentIdx, allStops, refreshKey]);

  if (!origin || allStops.length < 2) {
    return (
      <div className="flex items-center justify-center h-[460px] border border-[#2A2A30] rounded-xl text-[#8E9299] text-sm">
        No route stops to display.
      </div>
    );
  }

  return (
    <div className="flex flex-col border border-[#2A2A30] bg-[#0A0A0C] rounded-xl overflow-hidden h-[480px]">

      {/* ── Top bar ── */}
      <div className="flex items-center gap-2 px-3 py-2 border-b border-[#2A2A30] shrink-0 bg-[#0D0D12]">
        <span className="text-[10px] font-bold text-[#8E9299]">
          {started ? `Stop ${currentIdx} of ${totalLegs}` : `${studentStops.length} stops · tap START`}
        </span>
        <div className="flex-1" />
        <button onClick={() => setRefreshKey(k => k + 1)}
          className="p-1.5 rounded-lg bg-[#1A1A1F] border border-[#2A2A30] text-[#8E9299] hover:text-white transition-all" title="Refresh">
          <RefreshCw className="w-3 h-3" />
        </button>
        <a href={fullNavUrl} target="_blank" rel="noopener noreferrer"
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[10px] font-bold bg-[#1A1A1F] border border-[#2A2A30] text-[#8E9299] hover:text-white transition-all">
          <ExternalLink className="w-3 h-3" /> Full Route
        </a>
        <a href={legNavUrl} target="_blank" rel="noopener noreferrer"
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[10px] font-bold bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/20 transition-all">
          <ExternalLink className="w-3 h-3" /> Navigate
        </a>
      </div>

      {/* ── Stop info card ── */}
      {started && from && to && (
        <div className="shrink-0 px-4 py-2.5 border-b border-[#2A2A30] bg-[#0D0D12] flex items-center gap-3">
          <div className="flex flex-col min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <span className="text-[9px] font-bold text-emerald-400 uppercase tracking-wide">FROM</span>
              <span className="text-[11px] font-bold text-white truncate">{from.name}</span>
            </div>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="text-[9px] font-bold text-blue-400 uppercase tracking-wide">TO</span>
              <span className="text-[11px] font-bold text-[#F59E0B] truncate">{to.name}</span>
              {(to as any).eta && (
                <span className="text-[9px] text-[#8E9299] ml-auto shrink-0">ETA {(to as any).eta}</span>
              )}
            </div>
          </div>
          <div className="text-[10px] font-bold text-[#8E9299] shrink-0">
            {currentIdx + 1}/{totalLegs}
          </div>
        </div>
      )}

      {/* ── Map ── */}
      <div className="flex-1 relative min-h-0">
        {!started ? (
          // Pre-start screen
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-5 bg-[#0A0A0C]">
            <div className="text-center">
              <p className="text-lg font-bold text-white mb-1">🚌 Route Ready</p>
              <p className="text-xs text-[#8E9299]">{studentStops.length} stops · Roxy Sector</p>
              <p className="text-xs text-[#8E9299] mt-1">Navigate one stop at a time</p>
            </div>
            {/* Stop preview list */}
            <div className="w-full max-w-xs max-h-40 overflow-y-auto px-4 space-y-1">
              {allStops.map((s, i) => (
                <div key={i} className="flex items-center gap-2 text-[10px]">
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold shrink-0 text-[9px] ${
                    i === 0 ? 'bg-emerald-500 text-white' :
                    i === allStops.length - 1 ? 'bg-rose-500 text-white' :
                    'bg-[#F59E0B] text-black'
                  }`}>{i === 0 ? '▶' : i === allStops.length - 1 ? '🏁' : i}</span>
                  <span className="text-[#D1D5DB] truncate">{s.name}</span>
                </div>
              ))}
            </div>
            <button
              onClick={() => { setStarted(true); setCurrentIdx(0); }}
              className="flex items-center gap-2 px-8 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-sm transition-all shadow-lg shadow-emerald-500/20"
            >
              ▶ START ROUTE
            </button>
          </div>
        ) : (
          <iframe
            key={`${currentIdx}-${refreshKey}`}
            srcDoc={leafletHtml}
            className="absolute inset-0 w-full h-full border-0"
            title="Route Leg Map"
            sandbox="allow-scripts allow-same-origin"
          />
        )}
      </div>

      {/* ── Navigation controls ── */}
      {started && (
        <div className="shrink-0 border-t border-[#2A2A30] bg-[#0D0D12] px-4 py-2.5 flex items-center gap-3">
          <button
            onClick={() => { if (currentIdx > 0) setCurrentIdx(i => i - 1); else setStarted(false); }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-[11px] font-bold bg-[#1A1A1F] border border-[#2A2A30] text-[#8E9299] hover:text-white transition-all"
          >
            ← {currentIdx === 0 ? 'Back' : 'Prev'}
          </button>

          {/* Progress dots */}
          <div className="flex-1 flex items-center justify-center gap-1 overflow-hidden">
            {allStops.slice(0, -1).map((_, i) => (
              <button key={i} onClick={() => setCurrentIdx(i)}
                className={`rounded-full transition-all shrink-0 ${
                  i === currentIdx ? 'w-4 h-2 bg-[#3B82F6]' :
                  i < currentIdx ? 'w-2 h-2 bg-emerald-500' :
                  'w-2 h-2 bg-[#2A2A30]'
                }`}
              />
            ))}
          </div>

          {isLast ? (
            <button
              onClick={() => { setStarted(false); setCurrentIdx(0); }}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-[11px] font-bold bg-emerald-500 text-white hover:bg-emerald-400 transition-all"
            >
              ✓ Done
            </button>
          ) : (
            <button
              onClick={() => setCurrentIdx(i => i + 1)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-[11px] font-bold bg-[#3B82F6] text-white hover:bg-blue-400 transition-all"
            >
              Next →
            </button>
          )}
        </div>
      )}
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
export default function InteractiveMap({
  students,
  routeStops,
  currentStopIndex,
  simulatedBusPos,
  trafficSegments,
  liveDriverPos,
  gpsStatus = 'idle',
  onRequestGps,
  onStopGps,
  onSelectStudent,
}: InteractiveMapProps) {
  const [mapViewMode, setMapViewMode] = useState<MapView>('directions');
  const [hoveredStop, setHoveredStop] = useState<string | null>(null);

  // ── SVG projection — real coordinate bounds from GPS data ─────────────────
  const width = 640, height = 460;
  // Bounds: all 16 students + both hubs, with 15% padding
  const minLat = 30.0880, maxLat = 30.1000;
  const minLng = 31.3060, maxLng = 31.3310;

  const project = useCallback((lat: number, lng: number) => ({
    x: ((lng - minLng) / (maxLng - minLng)) * (width - 80) + 40,
    y: (1 - (lat - minLat) / (maxLat - minLat)) * (height - 80) + 40,
  }), []);

  // ── Real street geometry derived from GPS student coordinates ─────────────
  // Each road segment defined by actual GPS waypoints, not guesses
  const roads = useMemo(() => [
    {
      name: 'Khalifa El Mamoun St', id: 'khalifa',
      // Main east-west artery — traced from student coords on this street
      points: [
        { lat: 30.0910, lng: 31.3080 }, { lat: 30.0912, lng: 31.3100 },
        { lat: 30.0914, lng: 31.3120 }, { lat: 30.0917, lng: 31.3143 },
        { lat: 30.0920, lng: 31.3160 }, { lat: 30.0925, lng: 31.3180 },
        { lat: 30.0930, lng: 31.3200 }, { lat: 30.0935, lng: 31.3220 },
        { lat: 30.0940, lng: 31.3250 }, { lat: 30.0925, lng: 31.3297 },
      ],
    },
    {
      name: 'El Selahdar St', id: 'selahdar',
      // North-south — stud_1 (30.0911, 31.3179), stud_2 (30.0913, 31.3137), stud_3 (30.0945, 31.3142)
      points: [
        { lat: 30.0905, lng: 31.3179 }, { lat: 30.0911, lng: 31.3179 },
        { lat: 30.0913, lng: 31.3138 }, { lat: 30.0930, lng: 31.3140 },
        { lat: 30.0945, lng: 31.3142 }, { lat: 30.0958, lng: 31.3148 },
        { lat: 30.0965, lng: 31.3160 },
      ],
    },
    {
      name: 'Al Ashgar / Al Mafaza', id: 'ashgar',
      // stud_9/10 (30.093182, 31.313541), stud_11 (30.093158, 31.313623), stud_4 (30.0932, 31.3151)
      points: [
        { lat: 30.0920, lng: 31.3130 }, { lat: 30.0925, lng: 31.3136 },
        { lat: 30.0931, lng: 31.3136 }, { lat: 30.0932, lng: 31.3150 },
        { lat: 30.0935, lng: 31.3160 }, { lat: 30.0940, lng: 31.3175 },
      ],
    },
    {
      name: 'Al Shaheed Hussein Suleiman', id: 'hussein',
      // stud_12/13 (30.092979, 31.312038)
      points: [
        { lat: 30.0920, lng: 31.3110 }, { lat: 30.0925, lng: 31.3115 },
        { lat: 30.0930, lng: 31.3120 }, { lat: 30.0933, lng: 31.3130 },
      ],
    },
    {
      name: 'Sheikh Abu El Nour / Al Adfawi', id: 'abu_nour',
      // stud_14 (30.093510, 31.313508), stud_15/16 (30.093851, 31.310119)
      points: [
        { lat: 30.0935, lng: 31.3100 }, { lat: 30.0936, lng: 31.3110 },
        { lat: 30.0937, lng: 31.3120 }, { lat: 30.0935, lng: 31.3135 },
        { lat: 30.0940, lng: 31.3145 }, { lat: 30.0950, lng: 31.3129 },
      ],
    },
    {
      name: 'Connecting roads (Roxy sector)', id: 'connector',
      points: [
        { lat: 30.0900, lng: 31.3100 }, { lat: 30.0905, lng: 31.3110 },
        { lat: 30.0910, lng: 31.3120 }, { lat: 30.0915, lng: 31.3130 },
        { lat: 30.0920, lng: 31.3138 },
      ],
    },
  ], []);

  const getRoadColor = (id: string) => {
    const seg = trafficSegments.find(s => s.id === id);
    if (!seg) return '#1E2A3A';
    if (seg.status === 'heavy') return '#EF4444';
    if (seg.status === 'moderate') return '#F59E0B';
    return '#10B981';
  };

  // Group students by coordinate for SVG pins
  const studentPins = useMemo(() => {
    const groups: Record<string, { lat: number; lng: number; students: Student[] }> = {};
    students.forEach(s => {
      const key = `${s.lat.toFixed(5)},${s.lng.toFixed(5)}`;
      if (!groups[key]) groups[key] = { lat: s.lat, lng: s.lng, students: [] };
      groups[key].students.push(s);
    });
    return Object.values(groups);
  }, [students]);

  const svgPath = useMemo(() =>
    routeStops.map(s => project(s.lat, s.lng)),
    [routeStops, project]);

  const busSvgPos = useMemo(() => {
    if (simulatedBusPos) return project(simulatedBusPos.lat, simulatedBusPos.lng);
    if (routeStops[currentStopIndex]) return project(routeStops[currentStopIndex].lat, routeStops[currentStopIndex].lng);
    return null;
  }, [simulatedBusPos, routeStops, currentStopIndex, project]);

  return (
    <div className="bg-[#121217] rounded-2xl border border-[#2A2A30] p-5 shadow-xl shadow-black/10">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
          <h2 className="text-base font-bold text-[#F0F0F0] flex items-center gap-2 uppercase tracking-wide">
            <span className="w-2.5 h-2.5 rounded-full bg-[#3B82F6] animate-pulse" />
            Heliopolis Fleet Route Map
          </h2>
          <p className="text-xs text-[#8E9299]">Live route · OSM + OSRM · GPS-accurate</p>
        </div>

        {/* GPS button */}
        <div className="flex items-center gap-2 shrink-0">
          {gpsStatus === 'idle' && (
            <button onClick={onRequestGps} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[10px] font-bold bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 text-emerald-400 transition-all">
              <LocateFixed className="w-3.5 h-3.5" /> Use My Location
            </button>
          )}
          {gpsStatus === 'requesting' && (
            <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[10px] font-bold bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <LocateFixed className="w-3.5 h-3.5 animate-pulse" /> Requesting GPS…
            </span>
          )}
          {gpsStatus === 'active' && (
            <button onClick={onStopGps} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[10px] font-bold bg-emerald-500/10 hover:bg-rose-500/10 border border-emerald-500/20 hover:border-rose-500/20 text-emerald-400 hover:text-rose-400 transition-all">
              <LocateFixed className="w-3.5 h-3.5 animate-pulse" /> GPS Live · Stop
            </button>
          )}
          {gpsStatus === 'denied' && (
            <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[10px] font-bold bg-rose-500/10 border border-rose-500/20 text-rose-400">
              <LocateOff className="w-3.5 h-3.5" /> GPS Denied
            </span>
          )}
          {gpsStatus === 'unavailable' && (
            <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[10px] font-bold bg-[#2A2A30] border border-[#2A2A30] text-[#8E9299]">
              <LocateOff className="w-3.5 h-3.5" /> GPS Unavailable
            </span>
          )}
        </div>

        {/* View tabs */}
        <div className="flex bg-[#0A0A0C] border border-[#2A2A30] rounded-xl p-1 shrink-0 text-[10px] font-bold gap-0.5">
          {([
            { id: 'directions', label: 'Directions', icon: <Navigation className="w-3 h-3" />, color: 'bg-rose-500' },
            { id: '2d', label: '2D Flat', icon: null, color: 'bg-[#3B82F6]' },
            { id: '3d', label: '3D View', icon: <Layers className="w-3 h-3" />, color: 'bg-[#8B5CF6]' },

          ] as { id: MapView; label: string; icon: React.ReactNode; color: string }[]).map(tab => (
            <button
              key={tab.id}
              onClick={() => setMapViewMode(tab.id)}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg transition-all ${
                mapViewMode === tab.id ? `${tab.color} text-white` : 'text-[#8E9299] hover:text-[#F0F0F0]'
              }`}
            >
              {tab.icon}{tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── Directions Tab — Leaflet + OSRM ── */}
      {mapViewMode === 'directions' && (
        <DirectionsPanel stops={routeStops} liveDriverPos={liveDriverPos} />
      )}


            {/* ── SVG 2D / 3D View ── */}
      {(mapViewMode === '2d' || mapViewMode === '3d') && (
        <div
          style={{ perspective: mapViewMode === '3d' ? '900px' : 'none' }}
          className="relative border border-[#2A2A30] bg-[#0A0A0C] rounded-xl overflow-hidden shadow-2xl"
        >
          <div style={{
            transform: mapViewMode === '3d' ? 'rotateX(32deg) rotateZ(-10deg) scale(0.93)' : 'none',
            transformStyle: 'preserve-3d',
            transition: 'all 0.7s cubic-bezier(0.16,1,0.3,1)',
          }}>
            <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto select-none">
              <defs>
                <pattern id="grid" width="32" height="32" patternUnits="userSpaceOnUse">
                  <path d="M32 0L0 0 0 32" fill="none" stroke="#1A1A22" strokeWidth="0.8" />
                </pattern>
                <filter id="glow">
                  <feGaussianBlur stdDeviation="2" result="blur" />
                  <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
                </filter>
              </defs>

              <rect width="100%" height="100%" fill="#0A0A0C" />
              <rect width="100%" height="100%" fill="url(#grid)" />

              {/* Roads */}
              {roads.map(road => {
                const pts = road.points.map(p => project(p.lat, p.lng));
                const d = pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
                const roadColor = getRoadColor(road.id);
                return (
                  <g key={road.id}>
                    <path d={d} fill="none" stroke="#0A0A0C" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round" />
                    <path d={d} fill="none" stroke={roadColor} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" opacity="0.85" />
                    <path d={d} fill="none" stroke="rgba(255,255,255,0.04)" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" />
                  </g>
                );
              })}

              {/* Route path */}
              {svgPath.length > 1 && (
                <>
                  <polyline
                    points={svgPath.map(p => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ')}
                    fill="none" stroke="#1D4ED8" strokeWidth="5"
                    strokeLinecap="round" strokeLinejoin="round" opacity="0.5"
                  />
                  <polyline
                    points={svgPath.map(p => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ')}
                    fill="none" stroke="#60A5FA" strokeWidth="2.5"
                    strokeLinecap="round" strokeLinejoin="round"
                    strokeDasharray="12 8"
                  />
                </>
              )}

              {/* Hub markers */}
              {routeStops.filter(s => s.type === 'hub').map((stop, i) => {
                const { x, y } = project(stop.lat, stop.lng);
                const isStart = i === 0;
                const col = isStart ? '#10B981' : '#EF4444';
                return (
                  <g key={`hub-${i}`} filter="url(#glow)">
                    <circle cx={x} cy={y} r="14" fill={col} fillOpacity="0.15" stroke={col} strokeWidth="2" />
                    <circle cx={x} cy={y} r="6" fill={col} />
                    <text x={x} y={y - 20} textAnchor="middle" fontSize="9" fill={col} fontWeight="bold">
                      {isStart ? '🚌 START' : '🏁 END'}
                    </text>
                  </g>
                );
              })}

              {/* Student pins */}
              {studentPins.map((pin, i) => {
                const { x, y } = project(pin.lat, pin.lng);
                const boarded = pin.students.filter(s => s.boardingStatus === 'boarded').length;
                const total = pin.students.length;
                const col = boarded === total ? '#10B981' : boarded > 0 ? '#3B82F6' : '#F59E0B';
                const firstName = pin.students[0]?.name?.split(' ')[0] ?? '';
                const isHovered = hoveredStop === `${i}`;
                return (
                  <g
                    key={`pin-${i}`}
                    className="cursor-pointer"
                    onClick={() => onSelectStudent?.(pin.students[0]?.id)}
                    onMouseEnter={() => setHoveredStop(`${i}`)}
                    onMouseLeave={() => setHoveredStop(null)}
                  >
                    {/* Pin shadow */}
                    <circle cx={x} cy={y - 16} r={isHovered ? 11 : 9} fill="rgba(0,0,0,0.4)" transform="translate(1,2)" />
                    {/* Pin body */}
                    <circle cx={x} cy={y - 16} r={isHovered ? 11 : 9} fill={col} stroke="#0A0A0C" strokeWidth="1.5" />
                    <circle cx={x} cy={y - 16} r="3.5" fill="rgba(0,0,0,0.3)" />
                    {/* Pin stem */}
                    <line x1={x} y1={y - 7} x2={x} y2={y} stroke={col} strokeWidth="2" />
                    {/* Label */}
                    {(isHovered || total > 1) && (
                      <>
                        <rect x={x - firstName.length * 3 - 4} y={y - 36} width={firstName.length * 6 + 8} height={13} rx="5"
                          fill="#0A0A0C" fillOpacity="0.92" stroke={col} strokeWidth="1" />
                        <text x={x} y={y - 27} textAnchor="middle" fontSize="7.5" fill="#F3F4F6" fontWeight="600">{firstName}</text>
                      </>
                    )}
                    {/* Multi-student badge */}
                    {total > 1 && (
                      <circle cx={x + 8} cy={y - 22} r="6" fill="#8B5CF6" stroke="#0A0A0C" strokeWidth="1" />
                    )}
                    {total > 1 && (
                      <text x={x + 8} y={y - 19} textAnchor="middle" fontSize="6.5" fill="white" fontWeight="bold">{total}</text>
                    )}
                  </g>
                );
              })}

              {/* Live GPS dot */}
              {liveDriverPos && (() => {
                const { x, y } = project(liveDriverPos.lat, liveDriverPos.lng);
                return (
                  <g filter="url(#glow)">
                    <circle cx={x} cy={y} r="18" fill="none" stroke="#10B981" strokeWidth="1.5" opacity="0.3" />
                    <circle cx={x} cy={y} r="10" fill="#10B981" stroke="#0A0A0C" strokeWidth="2" />
                    <circle cx={x} cy={y} r="4" fill="white" />
                    <text x={x} y={y - 22} textAnchor="middle" fontSize="8" fill="#10B981" fontWeight="bold">YOU</text>
                  </g>
                );
              })()}

              {/* Bus icon */}
              {busSvgPos && (
                <g filter="url(#glow)">
                  <circle cx={busSvgPos.x} cy={busSvgPos.y} r="16" fill="#3B82F6" fillOpacity="0.2" stroke="#3B82F6" strokeWidth="1.5" />
                  <circle cx={busSvgPos.x} cy={busSvgPos.y} r="10" fill="#3B82F6" stroke="#0A0A0C" strokeWidth="1.5" />
                  <text x={busSvgPos.x} y={busSvgPos.y + 4} textAnchor="middle" fontSize="10">🚌</text>
                </g>
              )}
            </svg>
          </div>

          {/* Legend */}
          <div className="absolute bottom-3 left-3 bg-[#0A0A0C]/95 backdrop-blur rounded-lg border border-[#2A2A30] p-2.5 text-[9px] text-[#8E9299]">
            <p className="font-bold text-[#F0F0F0] mb-1.5 flex items-center gap-1.5">
              <Bus className="w-3 h-3 text-[#3B82F6]" /> Legend
            </p>
            <p className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#F59E0B] inline-block" /> Waiting</p>
            <p className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#3B82F6] inline-block" /> Partial</p>
            <p className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#10B981] inline-block" /> All Boarded</p>
          </div>
        </div>
      )}
    </div>
  );
}
